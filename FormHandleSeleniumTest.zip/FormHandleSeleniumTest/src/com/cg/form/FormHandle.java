package com.cg.form;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FormHandle {

	public static void main(String[] args) {
		
		
		
		System.setProperty("webdriver.chrome.driver","C://SeleninumJar//Chrome Driver//chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("C:\\SeleniumWork\\Lesson 5-HTML Pages\\Lesson 5-HTML Pages\\WorkingWithForms.html");
		
		
		driver.findElement(By.id("txtUserName")).sendKeys("Balaji123");
		
		
		
		driver.findElement(By.name("txtPwd")).sendKeys("balaji");
		
		
		driver.findElement(By.className("Format")).sendKeys("balaji");
		
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Balaji");
		
		
		driver.findElement(By.name("txtLN")).sendKeys("waghmare");
		
		
		
		driver.findElement(By.cssSelector("input[value='Male']")).click();
		
		
		
		driver.findElement(By.name("DtOB")).sendKeys("04/08/1996");
		
		
		driver.findElement(By.name("Email")).sendKeys("bs@gamil.com");
		
		
		
		driver.findElement(By.name("Address")).sendKeys("Maharashtra");
		
		
		
		Select drpCity=new Select(driver.findElement(By.name("City")));
		
		
		drpCity.selectByVisibleText("Pune");
		
		
		driver.findElement(By.name("Phone")).sendKeys("8551919844");
		
		List<WebElement> element=driver.findElements(By.name("chkHobbies"));
		
		
		for(WebElement val : element) {
			
			val.click();
			
			try {
				
				Thread.sleep(5000);
			}catch(Exception e) {
				
				e.printStackTrace();
				
			}
		}
		
			String title=driver.getTitle();
			
			System.out.println("The page title is: "+title);
			
			
			boolean b=driver.getPageSource().contains("Email Registration Form");
			
			if(b==true)
			{
				System.out.println("U got the right title");
			}
			else
			{
				System.out.println("Sorry .... Wrong title");
			}
		
		
			String currentURL;
			currentURL = driver.getCurrentUrl();
			System.out.println("The page current URL is :" + currentURL);
			
			//Find Submit button\
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			driver.findElement(By.name("submit")).click();
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//driver.close();
			driver.quit();

	}
	
	
	
}
