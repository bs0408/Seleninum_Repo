package com.cg.factory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class BrowserFactory {

	static WebDriver driver;

	public static WebDriver startBrowser(String name, String url) {
	
		if (name.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					"C://SeleninumJar//Chrome Driver//chromedriver.exe");
			driver = new ChromeDriver();
		} else if (name.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.firefox.driver",
					"D:\\Users\\rs55\\Documents\\My Received Files\\ActivityHotelManagement\\src\\test\\java\\Browser\\geckodriver.exe");
			driver = new FirefoxDriver();
		} else {
			System.setProperty("webdriver.ie.driver",
					"D:\\Users\\rs55\\Documents\\My Received Files\\ActivityHotelManagement\\src\\test\\java\\Browser\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.get(url);
		return driver;
	}
}
